package com.tmf.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Data;

@Entity
@Data
@Table(name = "partyaccount")
public class PartyAccount {

	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    
    @Column(columnDefinition = "INTEGER") // Specify exact column definition
    private Integer limit;
    
    @Column(columnDefinition = "INTEGER") // Specify exact column definition
    private Integer offset;
    
    @Column(name = "fields")
    private String fields;

	public PartyAccount(Long id, String fields, int offset, int limit) {
		super();
		this.id = id;
		this.fields = fields;
		this.offset = offset;
		this.limit = limit;
	}

	public PartyAccount() {
		super();
		// TODO Auto-generated constructor stub
	}

}
