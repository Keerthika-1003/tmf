package com.tmf.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.tmf.entity.PartyAccount;

public interface PartyAccountRepository extends JpaRepository<PartyAccount, Long> {

}
