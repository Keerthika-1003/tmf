package com.tmf.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.service.annotation.DeleteExchange;
import org.springframework.web.service.annotation.PatchExchange;

import com.tmf.entity.PartyAccount;
import com.tmf.repo.PartyAccountRepository;

@RestController
@RequestMapping("/tmf-api/accountManagement/v4/partyAccount")
public class PartyAccountController {

    @Autowired
    private PartyAccountRepository partyAccountRepository;
    
    @PostMapping("/createPartyAccount")
    public String createPartyAccount (@RequestBody PartyAccount partyAccount) {
    	partyAccountRepository.save(partyAccount);
    	return "Created";
    }
    
    

    @GetMapping("/listPartyAccount")
    public ResponseEntity<List<PartyAccount>> listPartyAccount() {
        List<PartyAccount> partyAccounts = partyAccountRepository.findAll();
        return new ResponseEntity<>(partyAccounts, HttpStatus.OK);
    }

    @GetMapping("/partyAccount/{id}")
    public PartyAccount retrievePartyAccount(@PathVariable Long id) {
    	return partyAccountRepository.getById(id);
    }
    
    @DeleteMapping("/partyAccount/{id}")
    public String deletePartyAccount(@PathVariable Long id) {
    	partyAccountRepository.deleteById(id);
    	return "Deleted";
    }
}
