package com.tmf;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TmfApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
